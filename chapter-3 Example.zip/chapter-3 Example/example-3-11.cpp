#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
    double circleRadius, towerHeight;
    circleRadius=12.67;
    towerHeight=12345.6789;
    
    cout<<fixed;
    cout<<showpoint;
    cout<<setprecision(3);
    cout<<" circleRadius = "<<circleRadius<<endl;
    cout<<" towerHeight = "<<towerHeight<<endl;
    return 0;
}