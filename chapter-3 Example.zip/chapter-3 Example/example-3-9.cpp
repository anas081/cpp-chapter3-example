#include<iostream>
using namespace std;

int main()
{
    string userName;
    
    cout<<"enter your name ";
    cin>>userName;
    cin.clear();
    cout<<"enter your name ";
    cin>>userName;
    cout<<userName;
    return 0;
}