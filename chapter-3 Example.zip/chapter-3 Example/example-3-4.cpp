#include<iostream>
#include<cmath>
#include<string>
using namespace std;

int main()
{
    double radiusSphere, volumeSphere;
    double xPoint1, yPoint1, xPoint2, yPoint2;
    double totalDistance;
    const double PI=3.1416;
    string textStr;
    
    cout<<"Enter the radius of the sphere: ";
    cin>>radiusSphere;
    cout<<endl;
    volumeSphere=(4/3)*PI*pow(radiusSphere, 3);
    cout<<" The volume of the sphere is: "<<volumeSphere<<endl<<endl;
    cout<<" Enter the coordinates of two points in the X-Y plane: ";
    cin>>xPoint1>>yPoint1>>xPoint2>>yPoint2;
    cout<<endl;
    totalDistance=sqrt(pow(xPoint2-xPoint1, 2)+pow(yPoint2-yPoint1, 2));
    cout<<"Line 23: The distance between the points "<<"("<<xPoint1<<", "<<yPoint1<<") and "<<"("<<xPoint2<<", "<<yPoint2<<") is: "<<totalDistance<<endl<<endl;
    textStr="Programming with C++";
    cout<<"The number of characters, "<<"including blanks, in \n \""<<textStr<<"\" is: "<<textStr.length()<<endl;
    return 0;
}