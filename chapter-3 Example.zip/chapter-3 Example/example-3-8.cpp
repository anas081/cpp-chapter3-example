#include<iostream>
using namespace std;

int main()
{
    string personName;
    int personAge, personWeight;
    double personHeight;
    personAge=0;
    personWeight=0;
    personHeight=0.0;
    
    cout<<"Line 10: Enter name, age, weight, and "<<"height: ";
    cin>>personName>>personAge>>personWeight>>personHeight;
    cout<<endl;
    cout<<"Line 13: Name: "<<personName<<endl;
    cout<<"Line 14: Age: "<<personAge<<endl;
    cout<<"Line 15: Weight: "<<personWeight<<endl;
    cout<<"Line 16: Height: "<<personHeight<<endl;
    return 0;
}