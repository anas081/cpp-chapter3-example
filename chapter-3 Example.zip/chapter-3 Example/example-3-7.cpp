#include<iostream>
using namespace std;

int main()
{
    char charInput;
    
    cout<<"Line 6: Enter a string: ";
    cin.get(charInput);
    cout<<endl;
    cout<<"Line 9: After first cin.get(charInput); "<<"charInput = "<<charInput<<endl;
    cin.get(charInput);
    cout<<"Line 11: After second cin.get(charInput); "<<"charInput = "<<charInput<<endl;
    cin.putback(charInput);
    cin.get(charInput);
    cout<<"Line 14: After putback and then "<<"cin.get(charInput); charInput = "<<charInput<<endl;
    charInput=cin.peek();
    cout<<"Line 16: After cin.peek(); charInput = "<<charInput<<endl;
    cin.get(charInput);
    cout<<"Line 18: After cin.get(charInput); charInput = "<<charInput<<endl;
    return 0;
}